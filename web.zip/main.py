from flask import Flask, redirect, render_template, session
from login_form import LoginForm
from add_news_form import AddNewsForm
from add_item_form import AddItemForm
from register_form import RegisterForm
from edit_item_form import EditItemForm
from db import DB
from user_model import UserModel
from news_model import NewsModel
from items_model import ItemsModel
from cart_model import CartModel

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

db = DB()


def exits(args):
    pass


# ## MAIN PART ## ## MAIN PART ## ## MAIN PART ##


@app.route('/', methods=['GET', 'POST'])
@app.route('/index', methods=['GET', 'POST'])
def index():
    if 'username' not in session:
        return redirect('/login')
    news = NewsModel(db.get_connection()).get_all()
    items = ItemsModel(db.get_connection()).get_all()
    return render_template('index.html', username=session['username'], news=news, items=items,
                           usermode=session['user_mode'])


@app.route('/manage', methods=['GET', 'POST'])
def manage():
    if 'username' not in session:
        return redirect('/login')
    if session['user_mode'] != 'admin':
        return redirect('/access_denied')
    users = UserModel(db.get_connection()).get_all()
    return render_template('manage_users.html', users=users)


@app.route('/cart')
def cart():
    if 'username' not in session:
        return redirect('/login')
    cm = CartModel(db.get_connection())
    cart_items = cm.get(session['user_id'])
    im = ItemsModel(db.get_connection())
    if cart_items is None:
        return render_template('cart.html', items=[], isnull=True, notenough=False)
    cart_items = cart_items[2].split()
    items = []
    for i in cart_items:
        i = i.split('/r/')
        item = im.get(i[0])
        if item is not None:
            items.append(list(item) + [i[1]])
    # items = [list(im.get(i.split('/r/')[0])) + [i.split('/r/')[1]] for i in cart_items if i is not None]
    summa = sum([int(i[3]) * int(i[6]) for i in items])
    return render_template('cart.html', items=items, isnull=False, summa=summa, notenough=False)


@app.route('/buy_cart', methods=['GET'])
def buy_cart():
    if 'username' not in session:
        return redirect('/login')
    cm = CartModel(db.get_connection())
    cart_items = cm.get(session['user_id'])[2].split()
    im = ItemsModel(db.get_connection())
    items = []
    for i in cart_items:
        i = i.split('/r/')
        item = im.get(i[0])
        if item is not None:
            items.append(list(item) + [i[1]])
    # items = [list(im.get(i.split('/r/')[0])) + [i.split('/r/')[1]] for i in cart_items]
    summa = sum([int(i[3]) * int(i[6]) for i in items])
    for i in cart_items:
        i = i.split('/r/')
        issuccess = im.buy(int(i[0]), int(i[1]))
        if not issuccess:
            return render_template('cart.html', items=items, isnull=False, summa=summa, notenough=True)
    cm.delete(session['user_id'])
    return render_template('successbuy.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user_name = form.username.data
        password = form.password.data
        user_model = UserModel(db.get_connection())
        exists = user_model.exists(user_name, password)
        if (exists[0]):
            session['username'] = user_name
            session['user_id'] = exists[1]
            session['user_mode'] = exists[2]
        return redirect("/index")
    return render_template('login.html', title='Авторизация', form=form)


# ## ADDING PART ## ## ADDING PART ## ## ADDING PART ##


@app.route('/add_news', methods=['GET', 'POST'])
def add_news():
    if 'username' not in session:
        return redirect('/login')
    if session['user_mode'] == 'user':
        return redirect('/access_denied')
    form = AddNewsForm()
    if form.validate_on_submit():
        title = form.title.data
        content = form.content.data
        nm = NewsModel(db.get_connection())
        nm.insert(title, content, session['user_id'])
        return redirect("/index")
    return render_template('add_news.html', title='Добавление новости', form=form, username=session['username'])


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        name = form.username.data
        password = form.password.data
        passwordagain = form.password_again.data
        email = form.email.data
        user_type = form.mode.data
        if password != passwordagain:
            return render_template('register.html', form=form, error=True, notmatch=True, userexist=False,
                                   emailexist=False)
        um = UserModel(db.get_connection())
        username_exist = um.username_exist(name)
        if username_exist:
            return render_template('register.html', form=form, error=False, notmatch=False, userexist=True,
                                   emailexist=False)
        emailexi = um.email_exist(email)
        if emailexi:
            return render_template('register.html', form=form, error=False, notmatch=False, userexist=False,
                                   emailexist=True)

        um.insert(name, password, email, user_type)
        exi = um.exists(name, password)
        session['username'] = name
        session['user_id'] = exi[1]
        session['user_mode'] = exi[2]
        return redirect("/succes_register")
    return render_template('register.html', form=form, error=True, notmatch=False, userexist=False, emilexist=False)


@app.route('/add_to_cart/<int:item_id>/<string:back>')
def add_to_cart(item_id, back):
    if 'username' not in session:
        return redirect('/login')
    cm = CartModel(db.get_connection())
    c = cm.get(session['user_id'])
    if c != [] and c is not None:
        cm.add_item(session['user_id'], item_id)
    else:
        cm.create(session['user_id'])
        cm.add_item(session['user_id'], item_id)
    if back == 'index':
        return redirect('/index')
    elif back == 'cart':
        return redirect('/cart')


@app.route('/add_item', methods=['GET', 'POST'])
def add_item():
    if session['user_mode'] == 'user':
        return redirect('/access_denied')
    form = AddItemForm()
    if form.validate_on_submit():
        name = form.name.data
        image = form.image.data
        price = form.price.data
        info = form.info.data
        count = form.count.data
        im = ItemsModel(db.get_connection())
        im.insert(name, image, price, info, count)
        return redirect("/index")
    return render_template('add_item.html', title='Добавление товара', form=form, username=session['username'])


@app.route('/edit_item/<int:item_id>', methods=['GET', 'POST'])
def edit_item(item_id):
    if session['user_mode'] == 'user':
        return redirect('/access_denied')
    form = EditItemForm()
    im = ItemsModel(db.get_connection())
    item_name = form.name.data
    item_image = form.image.data
    item_price = form.price.data
    item_info = form.info.data
    item_count = form.count.data
    updated_info = [item_name, item_image, item_price, item_info, item_count]
    print(updated_info)
    if form.validate_on_submit():
        if any(updated_info) is not None and any(updated_info) != '' and any(updated_info) != ' ':
            if item_name is not None and item_name != '' and item_name != ' ':
                im.edit('item_name', item_name, item_id)
            if item_image is not None and item_image != '' and item_image != ' ':
                im.edit('item_image', item_image, item_id)
            if item_price is not None and item_price != '' and item_price != ' ':
                im.edit('item_price', item_price, item_id)
            if item_info is not None and item_info != '' and item_info != ' ':
                im.edit('item_info', item_info, item_id)
            if item_count is not None and item_count != '' and item_count != ' ':
                im.edit('item_count', item_count, item_id)
            return redirect("/index")
    return render_template('edit_item.html', title='Редактирование товара', form=form, username=session['username'])


# DELETING PART ## DELETING PART ## DELETING PART


@app.route('/delete_item/<int:item_id>', methods=['GET'])
def delete_item(item_id):
    if 'username' not in session:
        return redirect('login')
    im = ItemsModel(db.get_connection())
    im.delete(item_id)
    return redirect('/index')


@app.route('/delete_item_from_cart_all/<int:item_id>')
def del_from_cart_all(item_id):
    if 'username' not in session:
        return redirect('/login')
    cm = CartModel(db.get_connection())
    cm.delete_from_cart_all(session['user_id'], item_id)
    return redirect('/cart')


@app.route('/delete_item_from_cart_one/<int:item_id>')
def del_from_cart_one(item_id):
    if 'username' not in session:
        return redirect('/login')
    cm = CartModel(db.get_connection())
    cm.delete_from_cart_one(session['user_id'], item_id)
    return redirect('/cart')


@app.route('/delete_news/<int:news_id>', methods=['GET'])
def delete_news(news_id):
    if 'username' not in session:
        return redirect('/login')
    nm = NewsModel(db.get_connection())
    nm.delete(news_id)
    return redirect("/index")


@app.route('/delete_user/<int:user_id>', methods=['GET'])
def delete_user(user_id):
    if 'username' not in session:
        return redirect('/login')
    if session['user_mode'] != 'admin':
        return redirect('/access_denied')
    um = UserModel(db.get_connection())
    um.delete_user(user_id)
    return redirect('/manage')


@app.route('/clear_cart', methods=['GET'])
def clear_cart():
    if 'username' not in session:
        return redirect('/login')
    cm = CartModel(db.get_connection())
    cm.delete(session['user_id'])
    return redirect('/cart')


# ## OTHER STUFF PART ## ## OTHER STUFF PART ## ## OTHER STUFF PART ##
@app.route('/succes_register')
def success_register():
    return render_template('succes_register.html', )


@app.route('/access_denied')
def access_denied():
    return render_template('access_denied.html')


@app.route('/error', methods=['GET', 'POST'])
def error():
    return "error, unknown user"


@app.route('/logout')
def logout():
    session.pop('username', 0)
    session.pop('user_id', 0)
    return redirect('/login')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)
