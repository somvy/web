from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Length


class EditItemForm(FlaskForm):
    name = StringField('Название товара',)
    image = TextAreaField('Ссылка на изображение',)
    price = StringField('Цена', )
    info = TextAreaField('Описание ',)
    count = StringField('Количество ',)
    submit = SubmitField('Добавить товар')
