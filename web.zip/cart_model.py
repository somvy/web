class CartModel:
    def __init__(self, connection):
        self.connection = connection

    def init_table(self):
        cursor = self.connection.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS cart 
                                    (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                                     user_id VARCHAR(50),
                                     items_id VARCHAR(400)
                                     )''')
        cursor.close()
        self.connection.commit()

    def create(self, user_id):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM cart WHERE user_id = ? ", (str(user_id),))
        row = cursor.fetchone()
        if not row:
            cursor.execute("INSERT INTO cart (user_id, items_id) VALUES (?,?)", (str(user_id), ' '))
        cursor.close()
        self.connection.commit()

    def get(self, user_id):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM cart WHERE user_id = ?", (str(user_id),))
        row = cursor.fetchone()
        return row

    def get_all(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM cart")
        rows = cursor.fetchall()
        return rows

    def delete(self, user_id):
        cursor = self.connection.cursor()
        cursor.execute('''DELETE FROM cart WHERE user_id = ?''', (str(user_id),))
        cursor.close()
        self.connection.commit()

    def clear_all(self):
        cursor = self.connection.cursor()
        cursor.execute('''DELETE FROM cart''')
        cursor.close()
        self.connection.commit()
        print('WARNING. CART TABLE WAS CLEARED')

    def update(self, user_id, items_id):
        cursor = self.connection.cursor()
        cursor.execute('''UPDATE cart SET items_id  = ?
                          WHERE user_id=?''', (str(items_id), str(user_id)))
        cursor.close()
        self.connection.commit()

    def add_item(self, user_id, item_id):
        cursor = self.connection.cursor()
        cursor.execute('''SELECT * FROM cart WHERE user_id = ?''', (str(user_id),))
        old_cart = str(cursor.fetchone()[2]).split()
        cursor.close()
        itemwas = False
        for i in old_cart:
            i = i.split('/r/')
            if str(item_id) in i:
                prev_value = '/r/'.join(i)
                i[1] = str(int(i[1]) + 1)
                itemwas = True
                old_cart.remove(prev_value)
                old_cart.append('/r/'.join(i))
                break
        if not itemwas:
            old_cart.append(str(item_id) + '/r/' + '1')
        self.update(user_id, ' '.join(old_cart))

    def delete_from_cart_all(self, user_id, item_id):
        cursor = self.connection.cursor()
        cursor.execute('''SELECT * FROM cart WHERE user_id = ?''', (str(user_id),))
        old_cart = cursor.fetchone()[2].split()
        cursor.close()
        for i in old_cart:
            i = i.split('/r/')
            if str(item_id) in i:
                old_cart.remove('/r/'.join(i))
                break
        self.update(user_id, ' '.join(old_cart))

    def delete_from_cart_one(self, user_id, item_id):
        cursor = self.connection.cursor()
        cursor.execute('''SELECT * FROM cart WHERE user_id = ?''', (str(user_id),))
        old_cart = cursor.fetchone()[2].split()
        cursor.close()
        for i in old_cart:
            i = i.split('/r/')
            if str(item_id) in i:
                prev_value = '/r/'.join(i)
                i[1] = str(int(i[1]) - 1)
                old_cart.remove(prev_value)
                if int(i[1]) > 0:
                    old_cart.append('/r/'.join(i))
                break
        self.update(user_id, ' '.join(old_cart))
